from pathlib import Path
import subprocess, sys, json
from fontTools.ttLib import TTFont

BASE=Path(__file__).resolve().parent
BRAND=BASE.parent
SOURCE=BASE/'IMG_0174_ORIGINAL.MOV'
FONTS=BASE/'FONTES' if (BASE/'FONTES').exists() else BRAND/'fontes-oficiais/render'

def run(args,log):
    with (BASE/log).open('w') as f:
        subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)

def ass_file(scale):
    W,H=1080*scale,1920*scale
    lines=[f'''[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
ScaledBorderAndShadow: yes
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Impact,Barlow Condensed Black,{78*scale},&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1
Style: Read,Inter,{32*scale},&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text''']
    def p(x):return round(x*scale)
    def e(start,style,tags,txt,layer=2):
        lines.append(f'Dialogue: {layer},0:00:{start:05.2f},0:00:08.00,{style},,0,0,0,,{{{tags}}}{txt}')
    e(.08,'Impact',fr'\move({p(-400)},{p(1060)},{p(540)},{p(1060)},0,550)\fs{p(210)}','BLACK FRIDAY')
    e(.35,'Impact',fr'\move({p(540)},{p(1325)},{p(540)},{p(1210)},0,600)\fs{p(152)}\fscx90\fscy90\t(0,600,\fscx100\fscy100)','CREATINA HARDCORE')
    e(.75,'Read',fr'\pos({p(540)},{p(1280)})\fs{p(46)}\fad(160,0)','INTEGRALMÉDICA • 500 g')
    # Linha vermelha com entrada lateral visível.
    e(.9,'Read',fr'\an7\move({p(-850)},{p(1320)},{p(150)},{p(1320)},0,500)\c&H002020FF&\p1',f'm 0 0 l {p(780)} 0 l {p(780)} {p(5)} l 0 {p(5)}',1)
    e(1.15,'Impact',fr'\move({p(760)},{p(1450)},{p(540)},{p(1450)},0,650)\fs{p(330)}\c&H002020FF&\fscx55\fscy55\t(0,430,\fscx108\fscy108)\t(430,650,\fscx100\fscy100)','R$ 89,90')
    e(1.6,'Read',fr'\pos({p(540)},{p(1590)})\fs{p(32)}\fad(180,0)','Aproveite a oferta na Central Suplementos.')
    # Botão vetorial nativo. Escala das coordenadas para cada saída.
    path=f'm {p(50)} 0 l {p(830)} 0 b {p(858)} 0 {p(880)} {p(22)} {p(880)} {p(50)} l {p(880)} {p(60)} b {p(880)} {p(88)} {p(858)} {p(110)} {p(830)} {p(110)} l {p(50)} {p(110)} b {p(22)} {p(110)} 0 {p(88)} 0 {p(60)} l 0 {p(50)} b 0 {p(22)} {p(22)} 0 {p(50)} 0'
    e(1.9,'Read',fr'\an7\move({p(1180)},{p(1660)},{p(100)},{p(1660)},0,650)\c&H000000F4&\p1',path,1)
    e(1.9,'Read',fr'\move({p(1620)},{p(1715)},{p(540)},{p(1715)},0,650)\fs{p(58)}','Chame no WhatsApp',3)
    e(2.25,'Read',fr'\pos({p(540)},{p(1815)})\fs{p(28)}\fad(180,0)','Consulte disponibilidade e condições.')
    dest=BASE/f'motion_{W}x{H}.ass';dest.write_text('\n'.join(lines),encoding='utf-8');return dest

def background():
    # 3 clipes em velocidade original: 8,5s menos duas dissoluções de .25s = 8s.
    flt='[0:v]fps=30,settb=AVTB,split=3[v0][v1][v2];[v0]setpts=PTS-STARTPTS,fps=30[a];[v1]setpts=PTS-STARTPTS,fps=30[b];[v2]setpts=PTS-STARTPTS,fps=30[c];[a][b]xfade=transition=fade:duration=0.25:offset=2.583333,fps=30[ab];[ab][c]xfade=transition=fade:duration=0.25:offset=5.166666,trim=duration=8,fps=30,format=yuv420p[v];[0:a]asplit=3[a0][a1][a2];[a0][a1]acrossfade=d=0.25:c1=tri:c2=tri[aa];[aa][a2]acrossfade=d=0.25:c1=tri:c2=tri,apad,atrim=duration=8,afade=t=in:d=0.06,afade=t=out:st=7.8:d=0.2[audio]'
    run(['ffmpeg','-y','-filter_complex_threads','2','-i',str(SOURCE),'-filter_complex',flt,'-map','[v]','-map','[audio]','-c:v','libx264','-crf','16','-preset','fast','-c:a','aac','-b:a','128k','-t','8',str(BASE/'base_8s.mp4')],'render_base.log')

def render(scale,fps):
    W,H=1080*scale,1920*scale
    ass=ass_file(scale)
    # Reenquadramento para cima: nome e marca ficam na região superior.
    filt=f'scale={W}:{1974*scale}:flags=lanczos,crop={W}:{1500*scale}:0:{300*scale},pad={W}:{H}:0:0:black,fps={fps},format=yuv420p'
    # Documento vetorial: gradiente contínuo, renderizado na resolução final.
    svg=BASE/f'contraste_{W}x{H}.svg'
    png=BASE/f'contraste_{W}x{H}.png'
    svg.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 1080 1920"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="black" stop-opacity="0"/><stop offset=".4" stop-color="black" stop-opacity=".35"/><stop offset=".75" stop-color="black" stop-opacity=".8"/><stop offset="1" stop-color="black" stop-opacity="1"/></linearGradient></defs><rect x="0" y="850" width="1080" height="650" fill="url(#g)"/><rect x="0" y="1500" width="1080" height="420" fill="black"/></svg>')
    subprocess.run(['inkscape',str(svg),'--export-type=png',f'--export-filename={png}','--export-background-opacity=0'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
    filt+=f"[base];movie='{png}'[shade];[base][shade]overlay=0:0:format=yuv420,subtitles='{ass}':fontsdir='{FONTS}',setsar=1"
    out=BASE/f'Central_Creatina_Motion_{W}x{H}_{fps}fps.mp4'
    (BASE/f'filtro_{W}x{H}.txt').write_text(filt)
    run(['ffmpeg','-y','-threads','4','-i',str(BASE/'base_8s.mp4'),'-vf',filt,'-c:v','libx264','-threads','4','-preset','veryfast','-crf','18' if scale==1 else '19','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:a','aac','-b:a','128k','-t','8','-movflags','+faststart',str(out)],f'render_{W}.log')
    return out

if __name__=='__main__':
    for f in ['BarlowCondensed-Black.ttf','Inter-Bold.ttf']:
        ft=TTFont(FONTS/f);print(f,'peso',ft['OS/2'].usWeightClass,flush=True)
    if not (BASE/'base_8s.mp4').exists() or (BASE/'base_8s.mp4').stat().st_size<1000:background()
    s=int(sys.argv[1]) if len(sys.argv)>1 else 1
    print(render(s,30 if s==1 else 60),flush=True)
